# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import pymysql

class ZhaobiaoPipeline:
    def __init__(self):
        self.mysql_conn = pymysql.Connection(
            host = 'localhost',
            port = 3306,
            user = 'root',
            password = '1234567890',
            database = 'zhaobiao',
            charset = 'utf8',
        )
    def process_item(self, item, spider): # 用于处理传递过来的数据
        # 创建光标对象
        cs = self.mysql_conn.cursor()
        # sql_str = 'insert into t_zhaobiao(字段,字段) value ("值","值","值")'
        sql_column = ','.join([key for key in item.keys()])
        sql_value = ','.join('"%s"' % [item[key] for key in item.key()])
        sql_str = 'insert into t_zhaobiao %s value %s' % (sql_column, sql_value)
        print(sql_str)

        # cs.execute('sql')
        # self.mysql_conn.commit()
        return item
